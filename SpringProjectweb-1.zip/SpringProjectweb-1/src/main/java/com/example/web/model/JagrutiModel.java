package com.example.web.model;

public class JagrutiModel {
	private Integer Id;
	private  String Name;
	private String Adress;
	private long Password;
	public JagrutiModel(Integer id, String name, String adress, long password) {
		super();
		Id = id;
		Name = name;
		Adress = adress;
		Password = password;
	}
	public JagrutiModel() {
		super();
	}
	public Integer getId() {
		return Id;
	}
	public void setId(Integer id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAdress() {
		return Adress;
	}
	public void setAdress(String adress) {
		Adress = adress;
	}
	public long getPassword() {
		return Password;
	}
	public void setPassword(long password) {
		Password = password;
	}

}
