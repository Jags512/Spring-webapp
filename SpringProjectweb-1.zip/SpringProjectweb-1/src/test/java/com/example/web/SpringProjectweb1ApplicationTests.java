package com.example.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringProjectweb1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
